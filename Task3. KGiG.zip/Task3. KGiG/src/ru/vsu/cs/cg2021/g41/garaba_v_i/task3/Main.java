package ru.vsu.cs.cg2021.g41.garaba_v_i.task3;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        MainWindow mainWindow = new MainWindow();
        mainWindow.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        mainWindow.setSize(800, 600);
        mainWindow.setVisible(true);
    }
}

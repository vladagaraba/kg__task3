package ru.vsu.cs.cg2021.g41.garaba_v_i.task3.spiral;

import ru.vsu.cs.cg2021.g41.garaba_v_i.task3.ScreenConverter;

import java.awt.*;

public interface iFigure {

    void drawMe(ScreenConverter screenConverter, Graphics2D g);
}

package ru.vsu.cs.cg2021.g41.garaba_v_i.task3;

import javax.swing.*;
import java.awt.*;

public class MainWindow extends JFrame {
    private final DrawPanel drawPanel;

    public MainWindow() throws HeadlessException {
        drawPanel = new DrawPanel();
        this.add(drawPanel);
        setExtendedState(MAXIMIZED_BOTH);
    }
}

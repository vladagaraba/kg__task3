package ru.vsu.cs.cg2021.g41.garaba_v_i.task3.spiral;

import ru.vsu.cs.cg2021.g41.garaba_v_i.task3.RealPoint;
import ru.vsu.cs.cg2021.g41.garaba_v_i.task3.ScreenConverter;
import ru.vsu.cs.cg2021.g41.garaba_v_i.task3.ScreenPoint;

import java.awt.*;
public class Spiral implements iFigure {

    private RealPoint rp;

    public Spiral(int width, int height) {
        int widthCenter = width / 2;
        int heightCenter = height / 2;
        rp = new RealPoint(widthCenter,heightCenter);
    }
    @Override
    public void drawMe(ScreenConverter screenConverter, Graphics2D g) {
        ScreenPoint sp = screenConverter.r2s(rp);
        for (int i = 0; i < 4 ; i++)
        {
            g.drawLine((int) (sp.getC() + (screenConverter.multipy(0.1) * i)),
                    sp.getR() - ((int)screenConverter.multipy(0.1) * i),
                    sp.getC() + ((int)screenConverter.multipy(0.1) * i),
                    sp.getR() + (int)screenConverter.multipy(0.1) + ((int)screenConverter.multipy(0.1) * i));
            g.drawLine(sp.getC() + ((int)screenConverter.multipy(0.1) * i),
                    sp.getR() + (int)screenConverter.multipy(0.1) + ((int)screenConverter.multipy(0.1) * i),
                    sp.getC() - (int)screenConverter.multipy(0.1) - ((int)screenConverter.multipy(0.1) * i),
                    sp.getR() + (int)screenConverter.multipy(0.1) + ((int)screenConverter.multipy(0.1) * i));
            g.drawLine(sp.getC() - (int)screenConverter.multipy(0.1) - ((int)screenConverter.multipy(0.1) * i),
                    sp.getR() + (int)screenConverter.multipy(0.1) + ((int)screenConverter.multipy(0.1) * i),
                    sp.getC() - (int)screenConverter.multipy(0.1) - ((int)screenConverter.multipy(0.1) * i),
                    sp.getR() - (int)screenConverter.multipy(0.1) - ((int)screenConverter.multipy(0.1) * i));
            g.drawLine(sp.getC() - (int)screenConverter.multipy(0.1) - ((int)screenConverter.multipy(0.1) * i),
                    sp.getR() - (int)screenConverter.multipy(0.1) - ((int)screenConverter.multipy(0.1) * i),
                    sp.getC() + (int)screenConverter.multipy(0.1) + ((int)screenConverter.multipy(0.1) * i),
                    sp.getR() - (int)screenConverter.multipy(0.1) - ((int)screenConverter.multipy(0.1) * i));
        }
    }
}
